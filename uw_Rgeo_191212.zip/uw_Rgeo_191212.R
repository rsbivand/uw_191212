
## ---- echo=TRUE-------------------------------------------------------------------------
needed <- c()


## ---- echo = FALSE, eval=FALSE----------------------------------------------------------
## BCrepos <- BiocManager::repositories()
## bioc <- available.packages(repo = BCrepos[1])
## bioc_ann <- available.packages(repo = BCrepos[2])
## bioc_exp <- available.packages(repo = BCrepos[3])
## cran <- available.packages()
## saveRDS(cran, file="cran_191209.rds")
## pdb <- rbind(cran, bioc, bioc_ann, bioc_exp)
## saveRDS(pdb, file="pdb_191209.rds")


## ---- echo = FALSE, eval=FALSE----------------------------------------------------------
## pdb <- readRDS("pdb_191209.rds")
## suppressPackageStartupMessages(library(miniCRAN))
## suppressPackageStartupMessages(library(igraph))
## suppressPackageStartupMessages(library(magrittr))
## pg <- makeDepGraph(pdb[, "Package"], availPkgs = pdb, suggests=TRUE, enhances=TRUE, includeBasePkgs = FALSE)
## pr <- pg %>%
##   page.rank(directed = FALSE) %>%
##   use_series("vector") %>%
##   sort(decreasing = TRUE) %>%
##   as.matrix %>%
##   set_colnames("page.rank")
##   cutoff <- quantile(pr[, "page.rank"], probs = 0.2)
## popular <- pr[pr[, "page.rank"] >= cutoff, ]
## toKeep <- names(popular)
## vids <- V(pg)[toKeep]
## gs <- induced.subgraph(pg, vids = toKeep)
## cl <- walktrap.community(gs, steps = 3)
## topClusters <- table(cl$membership) %>%
##   sort(decreasing = TRUE) %>%
##   head(25)
## cluster <- function(i, clusters, pagerank, n=10){
##   group <- clusters$names[clusters$membership == i]
##   pagerank[group, ] %>% sort(decreasing = TRUE) %>% head(n)
## }
## z <- lapply(names(topClusters)[1:15], cluster, clusters=cl, pagerank=pr, n=40)
## saveRDS(z, file="all_z_191209.rds")


## ----plot4a, cache=TRUE, echo=FALSE, eval=TRUE------------------------------------------
suppressPackageStartupMessages(library(wordcloud))
z <- readRDS("all_z_191209.rds")
oopar <- par(mar=c(0,0,0,0)+0.1)
wordcloud(names(z[[4]]), freq=unname(z[[4]])) # sf 2 sp 4
par(oopar)


## ---- echo = TRUE-----------------------------------------------------------------------
suppressPackageStartupMessages(library(osmdata))
library(sf)


## ---- cache=TRUE, echo = TRUE, eval=FALSE-----------------------------------------------
## bbox <- opq(bbox = 'bergen norway')
## byb0 <- osmdata_sf(add_osm_feature(bbox, key = 'railway',
##   value = 'light_rail'))$osm_lines
## tram <- osmdata_sf(add_osm_feature(bbox, key = 'railway',
##   value = 'tram'))$osm_lines
## byb1 <- tram[!is.na(tram$name),]
## o <- intersect(names(byb0), names(byb1))
## byb <- rbind(byb0[,o], byb1[,o])
## saveRDS(byb, file="byb.rds")

## ---- echo=FALSE, eval=TRUE-------------------------------------------------------------
byb <- readRDS("byb.rds")


## ---- echo = TRUE-----------------------------------------------------------------------
library(mapview)
mapview(byb)


## ---- echo = TRUE, eval=FALSE, cache=TRUE-----------------------------------------------
## bike_fls <- list.files("bbs")
## trips0 <- NULL
## for (fl in bike_fls) trips0 <- rbind(trips0,
##   read.csv(file.path("bbs", fl), header=TRUE))
## trips0 <- trips0[trips0[, 8] < 6 & trips0[, 13] < 6,]
## trips <- cbind(trips0[,c(1, 4, 2, 9)], data.frame(count=1))
## from <- unique(trips0[,c(4,5,7,8)])
## names(from) <- substring(names(from), 7)
## to <- unique(trips0[,c(9,10,12,13)])
## names(to) <- substring(names(to), 5)


## ---- echo = TRUE, eval=FALSE, cache=TRUE-----------------------------------------------
## # find origins and destinations and merge them
## stations0 <- st_as_sf(merge(from, to, all=TRUE),
##   coords=c("station_longitude", "station_latitude"))
## stations <- aggregate(stations0, list(stations0$station_id),
##   head, n=1)
## suppressWarnings(stations <- st_cast(stations, "POINT"))
## st_crs(stations) <- 4326


## ---- echo = TRUE, eval=FALSE, cache=TRUE-----------------------------------------------
## # sum trips between origins and destinations
## od <- aggregate(trips[,-(1:4)], list(trips$start_station_id,
##   trips$end_station_id), sum)


## ---- echo = TRUE, eval=FALSE, cache=TRUE-----------------------------------------------
## # drop equal origins and destinations
## od <- od[-(which(od[,1] == od[,2])),]
## # create desire lines
## library(stplanr)
## od_lines <- od2line(flow=od, zones=stations, zone_code="Group.1",
##   origin_code="Group.1", dest_code="Group.2")
## saveRDS(od_lines, "od_lines.rds")


## ----plot3, cache=TRUE, eval=TRUE-------------------------------------------------------
od_lines <- readRDS("od_lines.rds")
mapview(od_lines, alpha=0.2, lwd=(od_lines$x/max(od_lines$x))*10)


## ---- echo = TRUE, eval=FALSE, cache=TRUE-----------------------------------------------
## # allocate desirelines to cycle paths using CycleStreet
## Sys.setenv(CYCLESTREET="XxXxXxXxXxXxXxXx")
## od_routes <- line2route(od_lines, "route_cyclestreet",
##   plan = "fastest")
## saveRDS(od_routes, "od_routes.rds")


## ----plot4, cache=TRUE, eval=TRUE-------------------------------------------------------
od_routes <- readRDS("od_routes.rds")
mapview(od_routes, alpha=0.2, lwd=(od_lines$x/max(od_lines$x))*10)


## ---- echo = TRUE-----------------------------------------------------------------------
library(sp)
byb_sp <- as(byb, "Spatial")
str(byb_sp, max.level=2)


## ---- echo = TRUE-----------------------------------------------------------------------
str(slot(byb_sp, "lines")[[1]])


## ---- echo = TRUE, eval=FALSE-----------------------------------------------------------
## library(elevatr)
## elevation <- get_elev_raster(byb_sp, z = 10)
## is.na(elevation) <- elevation < 1
## saveRDS(elevation, file="elevation.rds")


## ---- echo = TRUE-----------------------------------------------------------------------
elevation <- readRDS("elevation.rds")
str(elevation, max.level=2)


## ---- echo=TRUE-------------------------------------------------------------------------
str(as(elevation, "SpatialGridDataFrame"), max.level=2)


## ---- echo = TRUE, eval=TRUE, message=FALSE, warning=FALSE------------------------------
mapview(elevation, col=terrain.colors)


## ---- echo = TRUE-----------------------------------------------------------------------
pt1 <- st_point(c(1,3))
pt2 <- pt1 + 1
pt3 <- pt2 + 1
str(pt3)


## ---- echo = TRUE-----------------------------------------------------------------------
st_as_text(pt3)


## ---- echo = TRUE-----------------------------------------------------------------------
st_as_binary(pt3)


## ---- echo = TRUE-----------------------------------------------------------------------
pt_sfc <- st_as_sfc(list(pt1, pt2, pt3))
str(pt_sfc)


## ---- echo = TRUE-----------------------------------------------------------------------
V1 <- 1:3
V2 <- letters[1:3]
V3 <- sqrt(V1)
V4 <- sqrt(as.complex(-V1))
L <- list(v1=V1, v2=V2, v3=V3, v4=V4)


## ---- echo = TRUE-----------------------------------------------------------------------
DF <- as.data.frame(L)
str(DF)
DF <- as.data.frame(L, stringsAsFactors=FALSE)
str(DF)


## ---- echo = TRUE-----------------------------------------------------------------------
DF$E <- list(d=1, e="1", f=TRUE)
str(DF)


## ---- echo = TRUE-----------------------------------------------------------------------
st_geometry(DF) <- pt_sfc
(DF)


## ---- echo = TRUE-----------------------------------------------------------------------
(buf_DF <- st_buffer(DF, dist=0.3))


## ---- echo=TRUE-------------------------------------------------------------------------
plot(st_geometry(buf_DF))
plot(st_geometry(DF), add=TRUE)


## ---- echo = TRUE-----------------------------------------------------------------------
library(stars)
fn <- system.file("tif/L7_ETMs.tif", package = "stars")
L7 <- read_stars(fn)
L7


## ---- echo = TRUE-----------------------------------------------------------------------
ndvi <- function(x) (x[4] - x[3])/(x[4] + x[3])
(s2.ndvi <- st_apply(L7, c("x", "y"), ndvi))


## ---- echo = TRUE-----------------------------------------------------------------------
L7p <- read_stars(fn, proxy=TRUE)
L7p


## ---- echo = TRUE-----------------------------------------------------------------------
(L7p.ndvi = st_apply(L7p, c("x", "y"), ndvi))


## ---- echo=TRUE-------------------------------------------------------------------------
sf_extSoftVersion()


## ---------------------------------------------------------------------------------------
sort(as.character(st_drivers("vector")$name))


## ---------------------------------------------------------------------------------------
sort(as.character(st_drivers("raster")$name))


## ---------------------------------------------------------------------------------------
library(RSQLite)
db = dbConnect(SQLite(), dbname="snow/b_pump.gpkg")
dbListTables(db)


## ---------------------------------------------------------------------------------------
str(dbReadTable(db, "gpkg_geometry_columns"))


## ---------------------------------------------------------------------------------------
str(dbReadTable(db, "b_pump")$geom)
dbDisconnect(db)


## ---------------------------------------------------------------------------------------
st_layers("snow/b_pump.gpkg")
st_layers("snow/nb_pump.gpkg")


## ---- warning=FALSE---------------------------------------------------------------------
library(rgdal)
ogrInfo("snow/nb_pump.gpkg")


## ---- warning=FALSE---------------------------------------------------------------------
rgdal::GDALinfo(fn)


## ---- warning=FALSE---------------------------------------------------------------------
library(raster)
(r <- raster(fn))


## ---------------------------------------------------------------------------------------
library(sp)
library(rgdal)
projInfo("ellps")[,c(1, 4)]


## ---------------------------------------------------------------------------------------
data("GridsDatums")
GridsDatums[grep("Norway", GridsDatums$country),]


## ---------------------------------------------------------------------------------------
EPSG <- make_EPSG()
EPSG[grep("Oslo", EPSG$note), 1:2]


## ---------------------------------------------------------------------------------------
(o <-CRS("+init=epsg:4817"))


## ---------------------------------------------------------------------------------------
list_coordOps("+proj=longlat +a=6377492.018 +rf=299.1528128 +pm=oslo +no_defs +type=crs", "EPSG:4326")


## ---------------------------------------------------------------------------------------
list_coordOps("EPSG:4817", "EPSG:4326")


## ---------------------------------------------------------------------------------------
getClass("CRS")


## ---------------------------------------------------------------------------------------
library(sf)
st_crs(4326)


## ---- echo = TRUE, mysize=TRUE, size='\\tiny'-------------------------------------------
library(RSQLite)
db <- dbConnect(SQLite(), dbname="/usr/local/share/proj/proj.db")
cat(strwrap(paste(dbListTables(db), collapse=", ")), sep="\n")
dbDisconnect(db)


## ---- echo=TRUE-------------------------------------------------------------------------
buildings <- sf::st_read("snow/buildings.gpkg", quiet=TRUE)
st_crs(buildings)


## ---- echo=TRUE-------------------------------------------------------------------------
library(mapview)
mapview(buildings)


## ---- echo=TRUE-------------------------------------------------------------------------
library(RSQLite)
db = dbConnect(SQLite(), dbname="snow/buildings.gpkg")
dbReadTable(db, "gpkg_spatial_ref_sys")$definition[4]
dbDisconnect(db)


## ---- echo=TRUE-------------------------------------------------------------------------
buildings1 <- rgdal::readOGR("snow/buildings.shp", verbose=FALSE)
proj4string(buildings1)


## ---- echo=TRUE-------------------------------------------------------------------------
mapview(buildings1)


## ---- echo=TRUE, warning=FALSE----------------------------------------------------------
readLines("snow/buildings.prj")


## ---------------------------------------------------------------------------------------
comment(slot(buildings1, "proj4string"))


## ---------------------------------------------------------------------------------------
(o <- CRS("+init=epsg:27700"))


## ---------------------------------------------------------------------------------------
comment(o)


## ---------------------------------------------------------------------------------------
cat(showSRID("+init=epsg:27700", multiline="YES"), "\n")


## ---------------------------------------------------------------------------------------
showSRID("+init=epsg:27700", "PROJ")


## ---------------------------------------------------------------------------------------
checkCRSArgs_ng


## ---- echo=TRUE, eval=FALSE, cache=TRUE-------------------------------------------------
## download.file("https://biogeo.ucdavis.edu/data/gadm3.6/Rsp/gadm36_NOR_0_sp.rds", "gadm36_NOR_0_sp.rds")


## ---- echo=TRUE-------------------------------------------------------------------------
nor <- readRDS("gadm36_NOR_0_sp.rds")
proj4string(nor)
comment(slot(nor, "proj4string"))


## ---------------------------------------------------------------------------------------
(o <- CRS(proj4string(nor)))
comment(o)


## ---------------------------------------------------------------------------------------
(c0 <- list_coordOps(paste0(proj4string(buildings1), " +type=crs"), "EPSG:4326"))


## ---------------------------------------------------------------------------------------
(c1 <- list_coordOps(comment(slot(buildings1, "proj4string")), "EPSG:4326"))


## ---------------------------------------------------------------------------------------
buildings1_ll <- spTransform(buildings1, CRS("+init=epsg:4326"))
get(".last_coordOp", envir=rgdal:::.RGDAL_CACHE)


## ---------------------------------------------------------------------------------------
mapview(buildings1_ll)


## ---------------------------------------------------------------------------------------
bp <- readOGR("snow/b_pump.gpkg")
comment(slot(bp, "proj4string"))


## ---------------------------------------------------------------------------------------
mapview(bp)


## ---------------------------------------------------------------------------------------
mapview(spTransform(bp, CRS("+init=epsg:4326")))

